#include "Mur.h"
#include <thread>
using namespace std;
Mur::Mur(Ekran *e) {
    this->e = e;
}
void Mur::work() {
     for (int i = 0; i < 20; ++i) {
        int start = rand() % 100 + 1;
        int velocity = rand() % 3 + 1;
       threads.push_back(std::thread(&Mur::buduj,this,start,velocity));
    }

    for (int i = 0; i < (signed)threads.size(); ++i) {
        threads[i].join();
    }

}
bool Mur::random_bool(){
    return rand()%2==1;
}
void Mur::buduj(int a, int b){
   	e->drawCegla(10,10,1);
    //takeoff(runway_time);
}
void Mur::drawQueue(){
    kolejka.lock();
    //s->drawRunwayQueue(runway_queue);
    kolejka.unlock();
}
